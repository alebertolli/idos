"""
idos.sdk.knowledge
Capa de persistencia híbrida: YAML estructurado + Markdown documental.
Documento 13: Arquitectura de Persistencia de Datos.

Principio: Git (archivos planos) es la fuente de verdad.
SQLite solo es índice. Este módulo escribe/lee archivos.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional, Type, TypeVar

import yaml
from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


class KnowledgeRepository:
    """Abstrae la estructura física de knowledge/ y journal/.

    En el MVP es un monorepo. En el futuro se separa en idos-knowledge
    e idos-journal sin cambiar esta interfaz.
    """

    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.knowledge_dir = self.root / "knowledge"
        self.journal_dir = self.root / "journal"

    # ------------------------------------------------------------------
    # Company / Knowledge Base (idos-knowledge)
    # ------------------------------------------------------------------

    def company_path(self, ticker: str) -> Path:
        return self.knowledge_dir / "companies" / ticker.upper()

    def write_company_meta(self, ticker: str, data: dict[str, Any]) -> Path:
        path = self.company_path(ticker) / "company.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
        return path

    def read_company_meta(self, ticker: str) -> Optional[dict[str, Any]]:
        path = self.company_path(ticker) / "company.yml"
        if not path.exists():
            return None
        return yaml.safe_load(path.read_text(encoding="utf-8"))

    def write_wiki(self, ticker: str, content: str) -> Path:
        path = self.company_path(ticker) / "static" / "wiki.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def read_wiki(self, ticker: str) -> str:
        path = self.company_path(ticker) / "static" / "wiki.md"
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8")

    def write_risks(self, ticker: str, content: str) -> Path:
        path = self.company_path(ticker) / "static" / "risks.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def write_dynamic_financials(self, ticker: str, data: dict[str, Any]) -> Path:
        path = self.company_path(ticker) / "dynamic" / "financials.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        return path

    def read_dynamic_financials(self, ticker: str) -> Optional[dict[str, Any]]:
        path = self.company_path(ticker) / "dynamic" / "financials.json"
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    # ------------------------------------------------------------------
    # Case File / Opportunity / Journal (idos-journal)
    # ------------------------------------------------------------------

    def opportunity_dir(self, ticker: str, opp_id: str) -> Path:
        return self.journal_dir / "companies" / ticker.upper() / opp_id

    def write_opportunity(self, ticker: str, opp_id: str, model: BaseModel) -> Path:
        path = self.opportunity_dir(ticker, opp_id) / "opportunity.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            yaml.dump(model.model_dump(mode="json"), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        return path

    def read_opportunity(self, ticker: str, opp_id: str, model_class: Type[T]) -> Optional[T]:
        path = self.opportunity_dir(ticker, opp_id) / "opportunity.yml"
        if not path.exists():
            return None
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        return model_class.model_validate(raw)

    def write_hypotheses(self, ticker: str, opp_id: str, hypotheses: list[BaseModel]) -> Path:
        path = self.opportunity_dir(ticker, opp_id) / "hypotheses.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        data = [h.model_dump(mode="json") for h in hypotheses]
        path.write_text(yaml.dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
        return path

    def read_hypotheses(self, ticker: str, opp_id: str) -> list[dict[str, Any]]:
        path = self.opportunity_dir(ticker, opp_id) / "hypotheses.yml"
        if not path.exists():
            return []
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []

    def write_assessment(self, ticker: str, opp_id: str, model: BaseModel) -> Path:
        assessments_dir = self.opportunity_dir(ticker, opp_id) / "assessments"
        assessments_dir.mkdir(parents=True, exist_ok=True)
        # Nombre con timestamp para no sobrescribir
        ts = model.generated_at.strftime("%Y%m%d_%H%M%S") if hasattr(model, "generated_at") else "manual"
        filename = f"{model.engine}_{ts}.yml".replace(" ", "_").lower()
        path = assessments_dir / filename
        path.write_text(
            yaml.dump(model.model_dump(mode="json"), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        return path

    def write_decision(self, ticker: str, opp_id: str, model: BaseModel) -> Path:
        decisions_dir = self.opportunity_dir(ticker, opp_id) / "decisions"
        decisions_dir.mkdir(parents=True, exist_ok=True)
        ts = model.executed_at.strftime("%Y%m%d_%H%M%S") if hasattr(model, "executed_at") else "manual"
        filename = f"{model.decision_type}_{ts}.yml".replace(" ", "_").lower()
        path = decisions_dir / filename
        path.write_text(
            yaml.dump(model.model_dump(mode="json"), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        return path

    def write_case_file(self, ticker: str, model: BaseModel) -> Path:
        path = self.journal_dir / "companies" / ticker.upper() / "case_file.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            yaml.dump(model.model_dump(mode="json"), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        return path

    # ------------------------------------------------------------------
    # Portfolio
    # ------------------------------------------------------------------

    def write_portfolio(self, data: dict[str, Any]) -> Path:
        path = self.journal_dir / "portfolio" / "positions.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
        return path

    def read_portfolio(self) -> Optional[dict[str, Any]]:
        path = self.journal_dir / "portfolio" / "positions.yml"
        if not path.exists():
            return None
        return yaml.safe_load(path.read_text(encoding="utf-8"))

    def write_watchlist(self, data: list[dict[str, Any]]) -> Path:
        path = self.journal_dir / "watchlist.yml"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
        return path
