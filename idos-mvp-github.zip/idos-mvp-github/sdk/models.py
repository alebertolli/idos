"""
idos.sdk.models
Modelos de dominio Pydantic para el IDOS MVP.
Fieles a la SDD Documento 4 (IKM) y Documento 13.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class OpportunityState(str, Enum):
    DISCOVERED = "DISCOVERED"
    SCREENED = "SCREENED"
    WATCHLIST = "WATCHLIST"
    UNDER_DEEP_DD = "UNDER_DEEP_DD"
    APPROVED = "APPROVED"
    ENTRY_PENDING = "ENTRY_PENDING"
    ACCUMULATING = "ACCUMULATING"
    FULL_POSITION = "FULL_POSITION"
    MONITORING = "MONITORING"
    REDUCING = "REDUCING"
    EXITED = "EXITED"
    POST_MORTEM = "POST_MORTEM"
    ARCHIVED = "ARCHIVED"


class HypothesisStatus(str, Enum):
    DRAFT = "DRAFT"
    ACTIVE = "ACTIVE"
    STRENGTHENING = "STRENGTHENING"
    CONFIRMED = "CONFIRMED"
    WEAKENING = "WEAKENING"
    AT_RISK = "AT_RISK"
    INVALIDATED = "INVALIDATED"
    CLOSED = "CLOSED"


class DecisionType(str, Enum):
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"
    ARCHIVE = "ARCHIVE"
    INVESTIGATE = "INVESTIGATE"


# ---------------------------------------------------------------------------
# Entidades de Knowledge (idos-knowledge)
# ---------------------------------------------------------------------------

class Company(BaseModel):
    """Entidad corporativa inmutable del mundo real."""
    ticker: str = Field(..., description="Ticker bursátil principal")
    isin: Optional[str] = None
    name_legal: str
    sector: str
    industry: str
    country: str
    exchange: str
    functional_currency: str = "USD"
    main_competitors: list[str] = Field(default_factory=list)
    ipo_date: Optional[str] = None

    class Config:
        extra = "forbid"


class Prediction(BaseModel):
    """Proyección observable con métrica, fecha límite y tolerancia."""
    id: str = Field(default_factory=lambda: f"PRED-{uuid.uuid4().hex[:8].upper()}")
    variable: str  # e.g., "EBIT Margin"
    expected_value: float
    expected_range: tuple[float, float]  # (low, high)
    deadline: datetime
    tolerance_pct: float = 5.0
    source_channel: str = "SEC 10-Q"
    observed_value: Optional[float] = None
    observed_at: Optional[datetime] = None
    status: Literal["PENDING", "FULFILLED", "MISSED", "PARTIAL"] = "PENDING"


class Hypothesis(BaseModel):
    """Supuesto contrastable y falsable. Documento 6."""
    id: str = Field(default_factory=lambda: f"HYP-{uuid.uuid4().hex[:8].upper()}")
    opportunity_id: str
    ticker: str
    version: int = 1
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    horizon_months: int = Field(..., ge=1, le=60)
    author: str = "human"  # o capability name
    status: HypothesisStatus = HypothesisStatus.DRAFT
    probability: float = Field(0.5, ge=0.0, le=1.0)
    confidence: Literal["High", "Medium", "Low"] = "Medium"

    # Bloques lógicos
    statement: str  # Hipótesis principal
    sub_hypotheses: list[str] = Field(default_factory=list)
    predictions: list[Prediction] = Field(default_factory=list)
    evidence_ids: list[str] = Field(default_factory=list)
    falsification_conditions: list[str] = Field(
        default_factory=list,
        description="Hechos que invalidan inmediatamente la hipótesis"
    )

    @field_validator("falsification_conditions")
    @classmethod
    def _non_empty_falsification(cls, v: list[str]) -> list[str]:
        if len(v) == 0:
            raise ValueError("Una hipótesis IDOS debe tener al menos 1 condición de falsación")
        return v


class Evidence(BaseModel):
    """Hecho o dato específico que apoya/debilita/refuta una hipótesis."""
    id: str = Field(default_factory=lambda: f"EVD-{uuid.uuid4().hex[:8].upper()}")
    description: str
    evidence_type: Literal["financial", "qualitative", "macro", "regulatory", "technical", "news"]
    source: str
    source_reliability: Literal["high", "medium", "low"] = "medium"
    event_date: Optional[datetime] = None
    impact: Literal["strong_support", "support", "neutral", "against", "strong_against"] = "neutral"
    linked_hypothesis_ids: list[str] = Field(default_factory=list)


class Rule(BaseModel):
    """Regla de negocio evaluada por el Decision Orchestrator."""
    id: str
    name: str
    description: str
    priority: int = Field(..., ge=0)
    condition: str  # Expresión lógica simple (evaluada por el orchestrator)
    action: Literal["PASS", "FAIL", "PROMOTE_TO_BUYLIST", "ALERT", "BLOCK"]
    version: int = 1
    active: bool = True


# ---------------------------------------------------------------------------
# Entidades de Journal (idos-journal)
# ---------------------------------------------------------------------------

class Conviction(BaseModel):
    """Objeto de convicción multidimensional. Documento 4, §5."""
    overall: int = Field(..., ge=0, le=100)
    business: int = Field(..., ge=0, le=100)
    valuation: int = Field(..., ge=0, le=100)
    rerating: int = Field(..., ge=0, le=100)
    risk: int = Field(..., ge=0, le=100)
    portfolio_fit: int = Field(..., ge=0, le=100)
    confidence: Literal["High", "Medium", "Low"]
    trend: Literal["Improving", "Stable", "Deteriorating"] = "Stable"


class Assessment(BaseModel):
    """Evaluación analítica estandarizada. Documento 4, §4.7."""
    id: str = Field(default_factory=lambda: f"AST-{uuid.uuid4().hex[:8].upper()}")
    engine: str  # e.g., "BusinessAssessmentEngine", "ValuationAssessmentEngine"
    version: str = "1.0"
    status: Literal["COMPLETE", "PARTIAL", "FAILED"] = "COMPLETE"
    score: int = Field(..., ge=0, le=100)
    confidence: Literal["High", "Medium", "Low"]
    findings: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    recommendation: str
    evidence_ids: list[str] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)  # IDs de otros assessments
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ticker: str
    opportunity_id: Optional[str] = None


class Decision(BaseModel):
    """Registro formal e inmutable de una decisión. Documento 4, §4.9."""
    id: str = Field(default_factory=lambda: f"DEC-{uuid.uuid4().hex[:8].upper()}")
    decision_type: DecisionType
    ticker: str
    opportunity_id: str
    justification: str
    executed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    evidence_ids: list[str] = Field(default_factory=list)
    assessment_ids: list[str] = Field(default_factory=list)
    rules_applied: list[str] = Field(default_factory=list)
    authorizers: list[str] = Field(default_factory=list)  # human / capability names
    position_size_pct: Optional[float] = None
    target_price: Optional[float] = None
    notes: str = ""


class Opportunity(BaseModel):
    """Ventana concreta de asignación de capital. Documento 4, §4.4."""
    id: str  # e.g., OPP-2026-001
    ticker: str
    state: OpportunityState = OpportunityState.DISCOVERED
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    expected_return_pct: Optional[float] = None
    investment_horizon_months: int = 24
    conviction: Optional[Conviction] = None
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    assessments: list[Assessment] = Field(default_factory=list)
    decisions: list[Decision] = Field(default_factory=list)
    target_price: Optional[float] = None
    position_size_pct: Optional[float] = None
    stop_loss_price: Optional[float] = None

    # Campos para el pipeline MVP
    current_price: Optional[float] = None
    pe_ratio: Optional[float] = None
    ev_ebitda: Optional[float] = None
    roe: Optional[float] = None
    net_debt_ebitda: Optional[float] = None
    ebit_margin: Optional[float] = None


class PortfolioPosition(BaseModel):
    """Estado físico de exposición de capital en cartera."""
    ticker: str
    opportunity_id: str
    shares: int = 0
    avg_price: float = 0.0
    current_weight_pct: float = 0.0
    status: Literal["ACCUMULATING", "FULL_POSITION", "REDUCING", "EXITED"] = "ACCUMULATING"
    stop_loss_price: Optional[float] = None
    conviction_at_entry: Optional[Conviction] = None
    last_reviewed: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class CaseFile(BaseModel):
    """Expediente histórico del seguimiento analítico de una compañía."""
    ticker: str
    opened_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    status: Literal["ACTIVE", "CLOSED", "ARCHIVED"] = "ACTIVE"
    opportunities: list[str] = Field(default_factory=list)  # IDs de oportunidades
    strategic_notes: list[str] = Field(default_factory=list)
    post_mortem_ids: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Market Data (interfaz neutra)
# ---------------------------------------------------------------------------

class MarketDataSnapshot(BaseModel):
    """Snapshot de datos de mercado descargados."""
    ticker: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    current_price: Optional[float] = None
    pe_trailing: Optional[float] = None
    pe_forward: Optional[float] = None
    ev_ebitda: Optional[float] = None
    ev_sales: Optional[float] = None
    roe: Optional[float] = None
    roic: Optional[float] = None
    net_debt_ebitda: Optional[float] = None
    ebit_margin: Optional[float] = None
    gross_margin: Optional[float] = None
    revenue_growth_yoy: Optional[float] = None
    eps_growth_yoy: Optional[float] = None
    dividend_yield: Optional[float] = None
    market_cap: Optional[float] = None
    beta: Optional[float] = None
    short_interest_pct: Optional[float] = None
    insider_ownership_pct: Optional[float] = None
    fifty_two_week_low: Optional[float] = None
    fifty_two_week_high: Optional[float] = None
    volume_avg_30d: Optional[float] = None
    raw_info: dict[str, Any] = Field(default_factory=dict, description="Datos crudos del proveedor")
