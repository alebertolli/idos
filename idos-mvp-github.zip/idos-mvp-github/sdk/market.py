"""
idos.sdk.market
Capa de datos de mercado con interfaz abstracta.
Documento 15: SDK Contracts - Módulo de Mercado.
"""
from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from .models import MarketDataSnapshot


class MarketDataProvider(ABC):
    """Interfaz abstracta para proveedores de datos de mercado.

    Todo proveedor concreto (yfinance, StockAnalysis, SEC EDGAR, etc.)
    implementa esta interfaz. El código de negocio nunca depende de un
    proveedor específico.
    """

    @abstractmethod
    def fetch_snapshot(self, ticker: str) -> MarketDataSnapshot:
        """Obtiene un snapshot completo de métricas para el ticker."""
        ...

    @abstractmethod
    def health_check(self) -> bool:
        """Verifica si el proveedor está disponible."""
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        ...


class YFinanceProvider(MarketDataProvider):
    """Implementación via yfinance (gratuito, suficiente para MVP).

    Requiere: pip install yfinance
    """

    def __init__(self, cache_dir: Optional[Path] = None) -> None:
        self._cache_dir = cache_dir
        self._ticker_cache: dict[str, Any] = {}
        try:
            import yfinance as yf  # type: ignore
            self._yf = yf
        except ImportError as exc:
            raise ImportError(
                "yfinance no está instalado. Ejecuta: pip install yfinance"
            ) from exc

    @property
    def provider_name(self) -> str:
        return "yfinance"

    def health_check(self) -> bool:
        try:
            t = self._yf.Ticker("AAPL")
            _ = t.info.get("symbol")
            return True
        except Exception:
            return False

    def fetch_snapshot(self, ticker: str) -> MarketDataSnapshot:
        """Descarga métricas clave via yfinance y normaliza al snapshot IDOS."""
        yf_ticker = self._yf.Ticker(ticker)
        info: dict[str, Any] = yf_ticker.info or {}

        # Helper para extraer floats de forma segura
        def _f(key: str) -> Optional[float]:
            val = info.get(key)
            if val is None:
                return None
            try:
                return float(val)
            except (TypeError, ValueError):
                return None

        snapshot = MarketDataSnapshot(
            ticker=ticker,
            timestamp=datetime.now(timezone.utc),
            current_price=_f("currentPrice") or _f("regularMarketPrice"),
            pe_trailing=_f("trailingPE"),
            pe_forward=_f("forwardPE"),
            ev_ebitda=_f("enterpriseToEbitda"),
            ev_sales=_f("enterpriseToRevenue"),
            roe=_f("returnOnEquity"),
            roic=_f("returnOnCapitalEmployed") or _f("roic"),
            net_debt_ebitda=_f("netDebtToEBITDA"),
            ebit_margin=_f("ebitdaMargins"),  # yfinance no siempre tiene EBIT puro
            gross_margin=_f("grossMargins"),
            revenue_growth_yoy=_f("revenueGrowth"),
            eps_growth_yoy=_f("earningsGrowth"),
            dividend_yield=_f("dividendYield"),
            market_cap=_f("marketCap"),
            beta=_f("beta"),
            short_interest_pct=_f("shortPercentOfFloat"),
            insider_ownership_pct=_f("heldPercentInsiders"),
            fifty_two_week_low=_f("fiftyTwoWeekLow"),
            fifty_two_week_high=_f("fiftyTwoWeekHigh"),
            volume_avg_30d=_f("averageVolume"),
            raw_info=info,
        )

        # Cache opcional a disco
        if self._cache_dir:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path = self._cache_dir / f"{ticker}_{snapshot.timestamp.strftime('%Y%m%d')}.json"
            cache_path.write_text(snapshot.model_dump_json(indent=2), encoding="utf-8")

        return snapshot


class MarketDataLayer:
    """Fachada que orquesta proveedores y fallback. MVP: un solo proveedor."""

    def __init__(
        self,
        primary: Optional[MarketDataProvider] = None,
        cache_dir: Optional[Path] = None,
    ) -> None:
        self.primary = primary or YFinanceProvider(cache_dir=cache_dir)
        self._cache_dir = cache_dir

    def get_snapshot(self, ticker: str, use_cache: bool = True) -> MarketDataSnapshot:
        """Obtiene snapshot. En el futuro: intenta primario, luego fallback."""
        # TODO: implementar cache read cuando se añada Redis/SQLite
        return self.primary.fetch_snapshot(ticker)

    def health_check(self) -> dict[str, bool]:
        return {
            self.primary.provider_name: self.primary.health_check(),
        }
