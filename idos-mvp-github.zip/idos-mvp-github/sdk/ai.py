"""
idos.sdk.ai
Wrapper multi-proveedor para LLM.
Soporta: OpenAI, Google Gemini, Mistral AI, OpenRouter.
Documento 15: SDK Contracts — Módulo de IA.
Documento 16: Resiliencia — Capa 2 Multi-Provider Failover (MVP: selección manual).
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Any, Optional


class LLMProvider(ABC):
    """Interfaz abstracta para proveedores de LLM."""

    @abstractmethod
    def complete(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        ...


# ---------------------------------------------------------------------------
# OpenAI
# ---------------------------------------------------------------------------
class OpenAIProvider(LLMProvider):
    """Implementación via OpenAI API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4o-mini") -> None:
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("Se requiere OPENAI_API_KEY")
        self.model = model
        try:
            from openai import OpenAI  # type: ignore
            self._client = OpenAI(api_key=self.api_key)
        except ImportError as exc:
            raise ImportError("openai no está instalado. Ejecuta: pip install openai") from exc

    @property
    def provider_name(self) -> str:
        return f"openai:{self.model}"

    def complete(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,  # type: ignore
            temperature=temperature,
            max_tokens=2000,
        )
        return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# Google Gemini
# ---------------------------------------------------------------------------
class GeminiProvider(LLMProvider):
    """Implementación via Google Gemini API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "gemini-1.5-flash") -> None:
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("Se requiere GEMINI_API_KEY")
        self.model = model
        try:
            import google.generativeai as genai  # type: ignore
            genai.configure(api_key=self.api_key)
            self._client = genai.GenerativeModel(model)
        except ImportError as exc:
            raise ImportError("google-generativeai no está instalado. Ejecuta: pip install google-generativeai") from exc

    @property
    def provider_name(self) -> str:
        return f"gemini:{self.model}"

    def complete(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        # Gemini soporta system instruction en versiones recientes
        if system:
            try:
                self._client._system_instruction = system  # type: ignore
            except Exception:
                prompt = f"{system}\n\n{prompt}"
        response = self._client.generate_content(
            prompt,
            generation_config={"temperature": temperature, "max_output_tokens": 2000},
        )
        return response.text or ""


# ---------------------------------------------------------------------------
# Mistral AI
# ---------------------------------------------------------------------------
class MistralProvider(LLMProvider):
    """Implementación via Mistral AI API."""

    def __init__(self, api_key: Optional[str] = None, model: str = "mistral-medium") -> None:
        self.api_key = api_key or os.getenv("MISTRAL_API_KEY")
        if not self.api_key:
            raise ValueError("Se requiere MISTRAL_API_KEY")
        self.model = model
        try:
            from mistralai.client import MistralClient  # type: ignore
            self._client = MistralClient(api_key=self.api_key)
        except ImportError as exc:
            raise ImportError("mistralai no está instalado. Ejecuta: pip install mistralai") from exc

    @property
    def provider_name(self) -> str:
        return f"mistral:{self.model}"

    def complete(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        from mistralai.models.chat_completion import ChatMessage  # type: ignore
        chat_messages = [ChatMessage(**m) for m in messages]

        response = self._client.chat(
            model=self.model,
            messages=chat_messages,
            temperature=temperature,
            max_tokens=2000,
        )
        return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# OpenRouter
# ---------------------------------------------------------------------------
class OpenRouterProvider(LLMProvider):
    """Implementación via OpenRouter (acceso a múltiples modelos con una sola API key).

    Modelos recomendados:
    - "anthropic/claude-3.5-sonnet"
    - "google/gemini-1.5-pro"
    - "mistralai/mistral-medium"
    - "meta-llama/llama-3.1-70b-instruct"
    """

    def __init__(self, api_key: Optional[str] = None, model: str = "anthropic/claude-3.5-sonnet") -> None:
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        if not self.api_key:
            raise ValueError("Se requiere OPENROUTER_API_KEY")
        self.model = model
        try:
            from openai import OpenAI  # type: ignore
            self._client = OpenAI(
                base_url="https://openrouter.ai/api/v1",
                api_key=self.api_key,
            )
        except ImportError as exc:
            raise ImportError("openai no está instalado. Ejecuta: pip install openai") from exc

    @property
    def provider_name(self) -> str:
        return f"openrouter:{self.model}"

    def complete(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,  # type: ignore
            temperature=temperature,
            max_tokens=2000,
            extra_headers={
                "HTTP-Referer": "https://github.com/idos-mvp",
                "X-Title": "IDOS MVP",
            },
        )
        return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# AI Client — Fachada
# ---------------------------------------------------------------------------
class AIClient:
    """Fachada del cliente AI. MVP: un solo proveedor seleccionable.
    Futuro: failover automático, circuit breaker, routing dinámico.
    """

    PROVIDER_MAP: dict[str, type[LLMProvider]] = {
        "openai": OpenAIProvider,
        "gemini": GeminiProvider,
        "mistral": MistralProvider,
        "openrouter": OpenRouterProvider,
    }

    def __init__(self, provider: Optional[LLMProvider] = None, provider_name: Optional[str] = None) -> None:
        if provider:
            self.provider = provider
        elif provider_name:
            self.provider = self._create_provider(provider_name)
        else:
            self.provider = self._auto_select()

    def _create_provider(self, name: str) -> LLMProvider:
        """Crea un proveedor por nombre."""
        name_lower = name.lower()
        if name_lower not in self.PROVIDER_MAP:
            available = ", ".join(self.PROVIDER_MAP.keys())
            raise ValueError(f"Proveedor desconocido: {name}. Disponibles: {available}")
        return self.PROVIDER_MAP[name_lower]()

    def _auto_select(self) -> LLMProvider:
        """Selecciona automáticamente el primer proveedor con API key disponible.
        Orden de prioridad: OpenAI → Gemini → Mistral → OpenRouter.
        """
        env_map = {
            "OPENAI_API_KEY": OpenAIProvider,
            "GEMINI_API_KEY": GeminiProvider,
            "MISTRAL_API_KEY": MistralProvider,
            "OPENROUTER_API_KEY": OpenRouterProvider,
        }
        for env_var, provider_cls in env_map.items():
            if os.getenv(env_var):
                return provider_cls()
        available = ", ".join(env_map.keys())
        raise ValueError(f"No se encontró API key de LLM. Define una de: {available}")

    def generate(self, prompt: str, system: Optional[str] = None, temperature: float = 0.2) -> str:
        return self.provider.complete(prompt, system=system, temperature=temperature)

    def generate_assessment(self, prompt_template_name: str, context: dict[str, Any]) -> str:
        """Carga un prompt del registry y lo completa con contexto."""
        if prompt_template_name == "business_assessment":
            prompt = self._business_assessment_prompt(context)
        elif prompt_template_name == "valuation_assessment":
            prompt = self._valuation_assessment_prompt(context)
        else:
            raise ValueError(f"Prompt template desconocido: {prompt_template_name}")
        return self.generate(prompt, system=self._system_prompt())

    def _system_prompt(self) -> str:
        return (
            "Eres un analista de inversión institucional cuantitativo. "
            "Razonas con rigor, separas hechos de inferencias, y cuantificas siempre que puedes. "
            "Respondes en español o inglés según el contexto. "
            "Cuando generes YAML, asegúrate de que sea válido y completo."
        )

    def _business_assessment_prompt(self, ctx: dict[str, Any]) -> str:
        wiki = ctx.get("wiki", "")
        financials = ctx.get("financials", {})
        return f"""Actúa como el Business Assessment Engine del IDOS.

Tu tarea es evaluar la calidad del negocio de la empresa y generar un Assessment estructurado.

=== WIKI DE LA EMPRESA ===
{wiki}

=== DATOS FINANCIEROS CLAVE ===
{financials}

Genera EXACTAMENTE el siguiente YAML (sin markdown fences, sin explicaciones previas):

id: "auto"
engine: "BusinessAssessmentEngine"
version: "1.0"
status: "COMPLETE"
score: <0-100>
confidence: <High|Medium|Low>
findings:
  - "<hallazgo 1>"
  - "<hallazgo 2>"
  - "<hallazgo 3>"
risks:
  - "<riesgo 1>"
  - "<riesgo 2>"
recommendation: "<recomendación operativa en 1-2 oraciones>"
evidence_ids: []
dependencies: []
generated_at: "{ctx.get('timestamp', "")}"
ticker: "{ctx.get('ticker', "")}"
opportunity_id: "{ctx.get('opportunity_id', "")}"

Instrucciones para el score:
- 90-100: Negocio excepcional (moat amplio, ROIC >20%, crecimiento sostenido, management de clase mundial)
- 75-89: Buen negocio (ventajas competitivas claras, ROIC >15%, crecimiento robusto)
- 60-74: Negocio sólido pero con interrogantes (ROIC 10-15%, competencia intensa)
- 40-59: Negocio mediocre (sin moat claro, ROIC <10%, riesgos estructurales)
- 0-39: Negocio de baja calidad o en deterioro
"""

    def _valuation_assessment_prompt(self, ctx: dict[str, Any]) -> str:
        financials = ctx.get("financials", {})
        return f"""Actúa como el Valuation Assessment Engine del IDOS.

Evalúa la valoración actual de la empresa comparando múltiplos y margen de seguridad.

=== DATOS DE MERCADO ===
{financials}

Genera EXACTAMENTE el siguiente YAML:

id: "auto"
engine: "ValuationAssessmentEngine"
version: "1.0"
status: "COMPLETE"
score: <0-100>
confidence: <High|Medium|Low>
findings:
  - "<hallazgo 1>"
  - "<hallazgo 2>"
risks:
  - "<riesgo 1>"
recommendation: "<recomendación>"
evidence_ids: []
dependencies: []
generated_at: "{ctx.get('timestamp', "")}"
ticker: "{ctx.get('ticker', "")}"
opportunity_id: "{ctx.get('opportunity_id', "")}"

Instrucciones para el score:
- 90-100: Valoración excepcional (múltiplos históricamente bajos, margen de seguridad >40%)
- 75-89: Valoración atractiva (múltiplos por debajo de media histórica, margen 25-40%)
- 60-74: Valoración razonable (múltiplos en línea con histórico, margen 15-25%)
- 40-59: Valoración exigente (múltiplos por encima de media, margen <15%)
- 0-39: Sobrevalorada (múltiplos extremos, sin margen de seguridad)
"""
