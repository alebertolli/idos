#!/usr/bin/env python3
"""
main.py
Pipeline MVP del IDOS para una sola empresa (ej. MELI).

Flujo:
  1. Data Worker: descarga datos de mercado y los persiste.
  2. AI Worker: genera Business Assessment via LLM.
  3. Decision Orchestrator: evalúa reglas YAML y determina estado.
  4. Persistencia: guarda oportunidad, assessment y decisión en journal/.

Uso:
  export OPENAI_API_KEY=sk-...
  # o GEMINI_API_KEY, MISTRAL_API_KEY, OPENROUTER_API_KEY
  pip install -r requirements.txt
  python main.py --pipeline MELI
  python main.py --pipeline MELI --provider gemini
  python main.py --pipeline MELI --provider mistral --model mistral-large-latest
  python main.py --pipeline MELI --provider openrouter --model anthropic/claude-3.5-sonnet

  # Solo descargar datos
  python main.py --fetch MELI

  # Solo evaluar reglas sobre oportunidad existente
  python main.py --evaluate MELI --opp-id OPP-2026-001
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import yaml

# Asegurar que el SDK local esté en path
sys.path.insert(0, str(Path(__file__).parent))

from sdk import (
    AIClient,
    Assessment,
    Conviction,
    Decision,
    DecisionType,
    KnowledgeRepository,
    MarketDataLayer,
    Opportunity,
    OpportunityState,
    YFinanceProvider,
)


# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------
ROOT = Path(__file__).parent
KNOWLEDGE = KnowledgeRepository(ROOT)
MARKET = MarketDataLayer(primary=YFinanceProvider(cache_dir=ROOT / "knowledge" / "cache"))

RULES_PATH = ROOT / "rules" / "entry.yml"


def load_rules() -> list[dict]:
    if not RULES_PATH.exists():
        return []
    data = yaml.safe_load(RULES_PATH.read_text(encoding="utf-8"))
    return data.get("rules", [])


# ---------------------------------------------------------------------------
# Paso 1: Data Worker
# ---------------------------------------------------------------------------
def step1_fetch_market_data(ticker: str) -> dict:
    print(f"[1/4] Data Worker: descargando datos de mercado para {ticker}...")
    snapshot = MARKET.get_snapshot(ticker)

    # Persistir en knowledge/dynamic
    financials = snapshot.model_dump(mode="json")
    KNOWLEDGE.write_dynamic_financials(ticker, financials)

    print(f"       ✓ Precio: {snapshot.current_price}")
    print(f"       ✓ P/E trailing: {snapshot.pe_trailing}")
    print(f"       ✓ EV/EBITDA: {snapshot.ev_ebitda}")
    print(f"       ✓ ROE: {snapshot.roe}")
    print(f"       ✓ Guardado en knowledge/companies/{ticker}/dynamic/financials.json")

    return financials


# ---------------------------------------------------------------------------
# Paso 2: AI Worker - Business Assessment
# ---------------------------------------------------------------------------
def step2_generate_assessment(ticker: str, opp_id: str, financials: dict, ai_client: AIClient) -> Assessment:
    print(f"[2/4] AI Worker: generando Business Assessment para {ticker}...")
    print(f"       Proveedor: {ai_client.provider.provider_name}")

    wiki = KNOWLEDGE.read_wiki(ticker)
    if not wiki:
        print(f"       ⚠ No se encontró wiki.md para {ticker}. Generando assessment con solo datos financieros.")
        wiki = "(Sin wiki disponible)"

    context = {
        "ticker": ticker,
        "opportunity_id": opp_id,
        "wiki": wiki,
        "financials": json.dumps(financials, indent=2, ensure_ascii=False, default=str),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    raw_yaml = ai_client.generate_assessment("business_assessment", context)

    # Limpiar posible markdown fence
    cleaned = raw_yaml.strip()
    if cleaned.startswith("```yaml"):
        cleaned = cleaned[7:]
    if cleaned.startswith("```"):
        cleaned = cleaned[3:]
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3]
    cleaned = cleaned.strip()

    try:
        data = yaml.safe_load(cleaned)
    except yaml.YAMLError as exc:
        print(f"       ✗ Error parseando YAML del LLM: {exc}")
        print(f"       Respuesta cruda:
{raw_yaml}")
        raise

    # Asegurar campos obligatorios
    data["ticker"] = ticker
    data["opportunity_id"] = opp_id
    data["generated_at"] = datetime.now(timezone.utc)
    data["id"] = f"AST-BIZ-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"

    assessment = Assessment.model_validate(data)
    KNOWLEDGE.write_assessment(ticker, opp_id, assessment)
    print(f"       ✓ Score: {assessment.score}/100")
    print(f"       ✓ Confianza: {assessment.confidence}")
    print(f"       ✓ Guardado en journal/companies/{ticker}/{opp_id}/assessments/")
    return assessment


# ---------------------------------------------------------------------------
# Paso 3: Decision Orchestrator
# ---------------------------------------------------------------------------
def step3_evaluate_rules(ticker: str, opp_id: str, assessment: Assessment) -> dict:
    print(f"[3/4] Decision Orchestrator: evaluando reglas de entrada...")

    rules = load_rules()
    if not rules:
        print("       ⚠ No se encontraron reglas. Usando lógica por defecto.")
        return {"decision": "HOLD", "rules_triggered": []}

    results = []
    all_passed = True

    for rule in rules:
        if not rule.get("active", True):
            continue

        condition = rule["condition"]
        passed = evaluate_condition(condition, assessment)
        results.append({
            "id": rule["id"],
            "name": rule["name"],
            "condition": condition,
            "passed": passed,
            "action": rule["action"],
            "priority": rule["priority"],
        })
        if rule["priority"] <= 3 and not passed:
            all_passed = False

        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"       {status} | {rule['id']}: {rule['name']} (priority {rule['priority']})")

    if all_passed:
        decision = "APPROVED"
        new_state = OpportunityState.APPROVED
    else:
        decision = "HOLD"
        new_state = OpportunityState.WATCHLIST

    print(f"       → Decisión: {decision}")
    return {"decision": decision, "new_state": new_state, "rules_triggered": results}


def evaluate_condition(condition: str, assessment: Assessment) -> bool:
    """Evaluador simple de condiciones. MVP: solo soporta score checks."""
    try:
        env = {
            "score": assessment.score,
            "confidence": assessment.confidence,
            "confidence_str": assessment.confidence,
        }
        expr = condition.replace("confidence == High", "confidence_str == 'High'")
        expr = expr.replace("confidence == Medium", "confidence_str == 'Medium'")
        expr = expr.replace("confidence == Low", "confidence_str == 'Low'")
        return bool(eval(expr, {"__builtins__": {}}, env))
    except Exception as exc:
        print(f"       ⚠ Error evaluando condición '{condition}': {exc}")
        return False


# ---------------------------------------------------------------------------
# Paso 4: Persistencia y Decisión
# ---------------------------------------------------------------------------
def step4_persist_decision(
    ticker: str,
    opp_id: str,
    assessment: Assessment,
    rule_result: dict,
    financials: dict,
) -> None:
    print(f"[4/4] Persistencia: actualizando oportunidad y decisión...")

    opp = Opportunity(
        id=opp_id,
        ticker=ticker,
        state=rule_result["new_state"],
        current_price=financials.get("current_price"),
        pe_ratio=financials.get("pe_trailing"),
        ev_ebitda=financials.get("ev_ebitda"),
        roe=financials.get("roe"),
        net_debt_ebitda=financials.get("net_debt_ebitda"),
        ebit_margin=financials.get("ebit_margin"),
        assessments=[assessment],
    )

    decision = Decision(
        decision_type=DecisionType.HOLD if rule_result["decision"] == "HOLD" else DecisionType.INVESTIGATE,
        ticker=ticker,
        opportunity_id=opp_id,
        justification=f"Evaluación automática MVP. Score: {assessment.score}. "
                      f"Decisión: {rule_result['decision']}. "
                      f"Reglas evaluadas: {len(rule_result['rules_triggered'])}",
        assessment_ids=[assessment.id],
        rules_applied=[r["id"] for r in rule_result["rules_triggered"]],
        authorizers=["idos-mvp-v1"],
    )

    opp.decisions.append(decision)

    KNOWLEDGE.write_opportunity(ticker, opp_id, opp)
    KNOWLEDGE.write_decision(ticker, opp_id, decision)

    print(f"       ✓ Oportunidad {opp_id} → estado: {opp.state.value}")
    print(f"       ✓ Decisión guardada en journal/companies/{ticker}/{opp_id}/decisions/")

    # Resumen final
    print("\n" + "=" * 60)
    print("RESUMEN EJECUCIÓN PIPELINE")
    print("=" * 60)
    print(f"Ticker:        {ticker}")
    print(f"Oportunidad:   {opp_id}")
    print(f"Precio actual: {financials.get('current_price', 'N/A')}")
    print(f"P/E trailing:  {financials.get('pe_trailing', 'N/A')}")
    print(f"EV/EBITDA:     {financials.get('ev_ebitda', 'N/A')}")
    print(f"ROE:           {financials.get('roe', 'N/A')}")
    print(f"Business Score:{assessment.score}/100")
    print(f"Confianza:     {assessment.confidence}")
    print(f"Recomendación: {assessment.recommendation}")
    print(f"Estado IDOS:   {opp.state.value}")
    print(f"Decisión:      {rule_result['decision']}")
    print("=" * 60)


# ---------------------------------------------------------------------------
# Comandos CLI
# ---------------------------------------------------------------------------
def build_ai_client(args) -> AIClient:
    """Construye el cliente AI según los argumentos del usuario."""
    if args.provider:
        return AIClient(provider_name=args.provider)
    return AIClient()


def cmd_pipeline(ticker: str, opp_id: str, ai_client: AIClient) -> None:
    financials = step1_fetch_market_data(ticker)
    assessment = step2_generate_assessment(ticker, opp_id, financials, ai_client)
    rule_result = step3_evaluate_rules(ticker, opp_id, assessment)
    step4_persist_decision(ticker, opp_id, assessment, rule_result, financials)


def cmd_fetch(ticker: str) -> None:
    step1_fetch_market_data(ticker)


def cmd_evaluate(ticker: str, opp_id: str) -> None:
    opp = KNOWLEDGE.read_opportunity(ticker, opp_id, Opportunity)
    if not opp:
        print(f"No se encontró oportunidad {opp_id} para {ticker}. Ejecuta --pipeline primero.")
        sys.exit(1)
    if not opp.assessments:
        print("No hay assessments para re-evaluar.")
        sys.exit(1)
    assessment = opp.assessments[-1]
    rule_result = step3_evaluate_rules(ticker, opp_id, assessment)
    print(f"\nResultado: {rule_result['decision']} → {rule_result['new_state'].value}")


def main() -> None:
    parser = argparse.ArgumentParser(description="IDOS MVP Pipeline")
    parser.add_argument("--pipeline", metavar="TICKER", help="Ejecutar pipeline completo")
    parser.add_argument("--fetch", metavar="TICKER", help="Solo descargar datos de mercado")
    parser.add_argument("--evaluate", metavar="TICKER", help="Re-evaluar reglas sobre oportunidad existente")
    parser.add_argument("--opp-id", default="OPP-2026-001", help="ID de oportunidad (default: OPP-2026-001)")
    parser.add_argument(
        "--provider",
        choices=["openai", "gemini", "mistral", "openrouter"],
        help="Proveedor de LLM (default: auto-detecta la primera API key disponible)",
    )
    parser.add_argument("--model", help="Modelo específico del proveedor (opcional)")
    args = parser.parse_args()

    ai_client = build_ai_client(args) if args.pipeline else None

    if args.pipeline:
        cmd_pipeline(args.pipeline.upper(), args.opp_id, ai_client)
    elif args.fetch:
        cmd_fetch(args.fetch.upper())
    elif args.evaluate:
        cmd_evaluate(args.evaluate.upper(), args.opp_id)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
