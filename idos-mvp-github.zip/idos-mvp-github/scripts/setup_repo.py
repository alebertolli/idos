#!/usr/bin/env python3
"""
scripts/setup_repo.py
Script de inicialización para el IDOS MVP en GitHub.
Verifica que la estructura esté completa y crea directorios faltantes.
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent

def check_structure():
    required = [
        "sdk/__init__.py",
        "sdk/models.py",
        "sdk/market.py",
        "sdk/knowledge.py",
        "sdk/ai.py",
        "main.py",
        "requirements.txt",
        "rules/entry.yml",
        "knowledge/companies/MELI/static/wiki.md",
        "journal/companies/MELI/OPP-2026-001/opportunity.yml",
        "journal/companies/MELI/OPP-2026-001/hypotheses.yml",
    ]

    missing = []
    for f in required:
        if not (ROOT / f).exists():
            missing.append(f)

    if missing:
        print("❌ Faltan archivos requeridos:")
        for f in missing:
            print(f"   - {f}")
        return False

    print("✅ Estructura del repo verificada. Todo en orden.")
    return True

def check_secrets():
    keys = {
        "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
        "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY"),
        "MISTRAL_API_KEY": os.getenv("MISTRAL_API_KEY"),
        "OPENROUTER_API_KEY": os.getenv("OPENROUTER_API_KEY"),
    }

    found = []
    for name, value in keys.items():
        if value:
            found.append(name)
            print(f"✅ {name} detectada ({len(value)} chars)")
        else:
            print(f"⚠️  {name} no detectada")

    if not found:
        print("❌ ERROR: Se requiere al menos una API key de LLM")
        print("   Define una de: OPENAI_API_KEY, GEMINI_API_KEY, MISTRAL_API_KEY, OPENROUTER_API_KEY")
        return False

    print(f"✅ {len(found)} proveedor(es) configurado(s)")
    return True

def check_dependencies():
    required = ["pydantic", "yaml", "yfinance"]
    optional = ["openai", "google.generativeai", "mistralai"]

    missing_required = []
    for mod in required:
        try:
            __import__(mod)
        except ImportError:
            missing_required.append(mod)

    if missing_required:
        print(f"❌ Faltan dependencias obligatorias: {', '.join(missing_required)}")
        print("   Ejecuta: pip install -r requirements.txt")
        return False

    print("✅ Dependencias principales instaladas")

    available_llm = []
    for mod in optional:
        try:
            __import__(mod)
            available_llm.append(mod)
        except ImportError:
            pass

    if available_llm:
        print(f"✅ SDKs de LLM disponibles: {', '.join(available_llm)}")
    else:
        print("⚠️  Ningún SDK de LLM instalado. Instala al menos uno:")
        print("   pip install openai  # o google-generativeai, mistralai")

    return True

def main():
    print("=" * 55)
    print("IDOS MVP — Verificación de entorno")
    print("=" * 55)

    ok = True
    ok &= check_structure()
    ok &= check_dependencies()
    ok &= check_secrets()

    print("=" * 55)
    if ok:
        print("✅ Todo listo. Puedes ejecutar:")
        print("   python main.py --pipeline MELI")
        print("   python main.py --pipeline MELI --provider gemini")
        print("   python main.py --pipeline MELI --provider mistral")
        print("   python main.py --pipeline MELI --provider openrouter")
    else:
        print("❌ Hay problemas. Corrige los errores arriba.")
        sys.exit(1)
    print("=" * 55)

if __name__ == "__main__":
    main()
