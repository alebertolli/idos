# MercadoLibre (MELI) - Riesgos Estructurales

## Riesgos Identificados

1. **Riesgo Regulatorio (Brasil):** Cambios en regulación de fintechs o tasas de interés.
2. **Riesgo Competitivo:** Amazon, Sea Limited (Shopee), Shein expandiendo en LATAM.
3. **Riesgo Macro:** Devaluación de monedas locales (ARS, BRL, MXN).
4. **Riesgo de Crédito:** Cartera de Mercado Crédito en expansión; NPLs podrían subir.
5. **Riesgo Logístico:** Altos capex en fulfillment; amortización lenta.

## Condiciones de Falsación Relevantes

- Caída del margen operativo global por debajo del 10% durante dos trimestres consecutivos.
- Pérdida de cuota de mercado en Brasil superior al 5% frente al principal competidor.
- NPLs en Mercado Crédito superando el 8% por más de un trimestre.
