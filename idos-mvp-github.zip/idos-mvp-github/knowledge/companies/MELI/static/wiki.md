# MercadoLibre (MELI) - Wiki de Conocimiento

> **Estado:** En construcción MVP  
> **Última revisión:** 2026-07-15  
> **Autor:** IDOS Human-in-the-Loop

---

## 1. Modelo de Negocio

MercadoLibre es la plataforma de comercio electrónico y pagos digitales líder en América Latina.

- **Marketplace:** Conecta compradores y vendedores en 18 países.
- **Mercado Pago:** Ecosistema de pagos digitales (fintech).
- **Mercado Envíos:** Red logística propia (fulfillment).
- **Mercado Crédito:** Servicios de crédito para vendedores y compradores.

**Motores de crecimiento:**
1. Penetración de e-commerce en LATAM (aún baja vs. EE.UU./China).
2. Expansion de Mercado Pago fuera del marketplace (pagos presenciales).
3. Maduración de la red logística (margen operativo en expansión).

---

## 2. Ventajas Competitivas (Moat)

- **Efectos de red:** Más compradores atraen más vendedores, y viceversa.
- **Datos:** 20+ años de datos transaccionales en LATAM.
- **Infraestructura logística:** Centros de fulfillment difíciles de replicar.
- **Ecosistema cerrado:** Pago + envío + crédito + marketplace integrados.

**Evaluación del moat:** Estrecho pero profundo. Amazon no ha logrado desplazar a MELI en LATAM.

---

## 3. Management y Asignación de Capital

- **CEO:** Marcos Galperin (fundador, still active).
- **Track record:** Enfocado en reinversión agresiva y ganancia de cuota de mercado.
- **Asignación de capital:** Prioriza crecimiento sobre dividendos; compras de acciones ocasionales.

---

## 4. Catalizadores Potenciales

1. Expansión de márgenes operativos en Brasil por maduración logística.
2. Crecimiento de Mercado Pago en México y Colombia.
3. Normalización de tasas de interés en Brasil (reduce costo de crédito).

---

## 5. Métricas Clave a Monitorear

- GMV (Gross Merchandise Value) y su crecimiento YoY.
- Take rate del marketplace.
- Margen operativo de la unidad logística.
- NPL (non-performing loans) en Mercado Crédito.
- ROIC y ROE.

---

*Nota: Este documento es un borrador humano. El sistema IDOS no lo modifica automáticamente; solo sugiere actualizaciones.*
