# IDOS MVP — GitHub Edition (Multi-Provider LLM)

> **Versión:** MVP 0.2 — Multi-Provider  
> **Proveedores soportados:** OpenAI, Google Gemini, Mistral AI, OpenRouter  
> **Entornos:** GitHub Codespaces + GitHub Actions  
> **No requiere Python local**

---

## ¿Qué es esto?

Versión del **Investment Decision Operating System (IDOS)** diseñada para ejecutarse **100% en la nube** via GitHub. No necesitas instalar Python en tu máquina.

**Dos modos de uso:**
1. **GitHub Codespaces** — VS Code completo en el navegador. Desarrollo interactivo, terminal, debug.
2. **GitHub Actions** — Ejecución automática o manual sin abrir el editor. Los resultados se guardan en el repo.

**Multi-Provider LLM:** Elige entre OpenAI, Gemini, Mistral AI o OpenRouter. El sistema auto-detecta la primera API key disponible, o puedes forzar un proveedor específico.

---

## 🚀 Inicio Rápido (3 minutos)

### Paso 1: Crea tu repo privado en GitHub

1. Ve a [github.com/new](https://github.com/new)
2. Nombre: `idos-mvp` (o el que prefieras)
3. **Privado** (obligatorio — aquí irán tus decisiones de inversión)
4. No inicialices con README (ya lo incluye este paquete)
5. Crea el repo.

### Paso 2: Sube este código

```bash
# En tu máquina (o en un codespace temporal)
unzip idos-mvp-github.zip
cd idos-mvp-github
git init
git remote add origin https://github.com/TU_USUARIO/idos-mvp.git
git add .
git commit -m "Initial commit: IDOS MVP v0.2"
git push -u origin main
```

### Paso 3: Configura tus secrets (API Keys)

En tu repo de GitHub:
1. Ve a **Settings** → **Secrets and variables** → **Actions** → **New repository secret**
2. Añade **al menos una** de estas:
   - `OPENAI_API_KEY` → tu key de OpenAI
   - `GEMINI_API_KEY` → tu key de Google AI Studio
   - `MISTRAL_API_KEY` → tu key de Mistral AI (console.mistral.ai)
   - `OPENROUTER_API_KEY` → tu key de OpenRouter (openrouter.ai)

> **Puedes configurar las 4.** El sistema usará la primera que encuentre (orden: OpenAI → Gemini → Mistral → OpenRouter), o puedes forzar un proveedor con `--provider`.

> **Importante:** Nunca guardes API keys en archivos del repo. GitHub Actions las inyecta automáticamente.

### Paso 4: Abre GitHub Codespaces

1. En tu repo, clic en el botón verde **<> Code**
2. Pestaña **Codespaces** → **Create codespace on main**
3. Espera 30-60 segundos. Se abre VS Code en el navegador.
4. La terminal inferior ya tiene Python 3.11 y las dependencias instaladas.

### Paso 5: Ejecuta tu primer pipeline

```bash
# Auto-detecta el primer proveedor con API key
python main.py --pipeline MELI

# Forzar un proveedor específico
python main.py --pipeline MELI --provider gemini
python main.py --pipeline MELI --provider mistral
python main.py --pipeline MELI --provider openrouter

# Forzar proveedor + modelo específico
python main.py --pipeline MELI --provider openrouter --model anthropic/claude-3.5-sonnet
python main.py --pipeline MELI --provider mistral --model mistral-large-latest
```

---

## 🧠 Proveedores de LLM

| Proveedor | Variable de entorno | Modelo por defecto | Modelos disponibles |
|-----------|---------------------|-------------------|---------------------|
| **OpenAI** | `OPENAI_API_KEY` | `gpt-4o-mini` | gpt-4o, gpt-4o-mini, gpt-3.5-turbo |
| **Google Gemini** | `GEMINI_API_KEY` | `gemini-1.5-flash` | gemini-1.5-pro, gemini-1.5-flash |
| **Mistral AI** | `MISTRAL_API_KEY` | `mistral-medium` | mistral-large-latest, mistral-medium, mistral-small |
| **OpenRouter** | `OPENROUTER_API_KEY` | `anthropic/claude-3.5-sonnet` | Cualquier modelo de OpenRouter (Claude, Llama, Qwen, etc.) |

### ¿Cuál elegir?

- **OpenAI** → Buen balance calidad/precio. GPT-4o-mini es barato y rápido.
- **Gemini** → Contexto muy largo (1M tokens). Ideal para wikis extensas. Google AI Studio es gratuito con límite.
- **Mistral** → Modelos europeos, buen rendimiento en español. Console de Mistral es muy limpia.
- **OpenRouter** → **La opción más flexible.** Acceso a Claude, Llama, Qwen, DeepSeek, etc. con una sola API key. Perfecto para experimentar.

### Obtener API Keys

- **OpenAI:** [platform.openai.com](https://platform.openai.com) → API Keys
- **Gemini:** [aistudio.google.com](https://aistudio.google.com) → Get API Key
- **Mistral:** [console.mistral.ai](https://console.mistral.ai) → API Keys
- **OpenRouter:** [openrouter.ai/keys](https://openrouter.ai/keys) → Create Key

---

## 📂 Estructura del Repo

```
idos-mvp/
├── .devcontainer/
│   └── devcontainer.json      # Configura Codespaces automáticamente
├── .github/
│   └── workflows/
│       ├── pipeline.yml       # Ejecutar pipeline completo (manual)
│       ├── fetch.yml          # Descargar datos de mercado (manual + auto)
│       └── scout.yml          # Scout semanal (ejemplo programado)
├── sdk/                       # SDK mínimo viable
│   ├── models.py              # Entidades Pydantic
│   ├── market.py              # Datos de mercado (yfinance)
│   ├── knowledge.py           # Persistencia YAML/Markdown
│   └── ai.py                  # ← Multi-proveedor: OpenAI, Gemini, Mistral, OpenRouter
├── knowledge/                 # Hechos verificables
│   └── companies/
│       └── MELI/
│           ├── static/
│           │   ├── wiki.md    # ← TÚ escribes esto
│           │   └── risks.md   # ← TÚ escribes esto
│           └── dynamic/
│               └── financials.json  # Auto: datos de mercado
├── journal/                   # Decisiones y procesos
│   └── companies/
│       └── MELI/
│           └── OPP-2026-001/
│               ├── opportunity.yml   # ← TÚ defines target, horizon
│               ├── hypotheses.yml    # ← TÚ escribes hipótesis + falsación
│               ├── assessments/      # Auto: generado por LLM
│               └── decisions/        # Auto: registro de decisiones
├── rules/
│   └── entry.yml              # Reglas de entrada
├── main.py                    # Entry point con --provider
├── requirements.txt           # Dependencias (incluye mistralai, google-generativeai)
└── README.md
```

---

## 🎮 Modo 1: GitHub Codespaces (Desarrollo Interactivo)

### Ventajas
- Terminal bash completa.
- VS Code con extensiones Python, YAML, Markdown.
- Puedes editar archivos, ejecutar scripts, ver resultados en tiempo real.
- Los cambios se guardan en el repo automáticamente (si haces commit).

### Comandos útiles

```bash
# Verificar que todo esté configurado
python scripts/setup_repo.py

# Pipeline con auto-detección de proveedor
python main.py --pipeline MELI

# Pipeline con proveedor específico
python main.py --pipeline MELI --provider gemini
python main.py --pipeline MELI --provider mistral --model mistral-large-latest
python main.py --pipeline MELI --provider openrouter --model meta-llama/llama-3.1-70b-instruct

# Solo descargar datos de mercado
python main.py --fetch MELI

# Re-evaluar reglas sobre oportunidad existente
python main.py --evaluate MELI --opp-id OPP-2026-001

# Ver archivos generados
ls -la journal/companies/MELI/OPP-2026-001/assessments/
ls -la journal/companies/MELI/OPP-2026-001/decisions/

# Commit manual de resultados
git add knowledge/ journal/
git commit -m "Resultados pipeline MELI"
git push
```

### Cambiar proveedor por defecto en Codespaces

Si tienes múltiples API keys configuradas y quieres forzar un proveedor:

```bash
export IDOS_PROVIDER=gemini
python main.py --pipeline MELI
```

O simplemente usa el flag `--provider`.

---

## ⚙️ Modo 2: GitHub Actions (Ejecución Automática)

### Workflow 1: Pipeline Completo (Manual)

1. Ve a tu repo en GitHub → pestaña **Actions**
2. Selecciona **"IDOS Pipeline — Ejecución Completa"**
3. Clic en **Run workflow**
4. Introduce:
   - **Ticker:** `MELI`
   - **Opp ID:** `OPP-2026-001`
   - **Provider:** (opcional) `gemini`, `mistral`, `openrouter` o deja vacío para auto-detectar
5. Clic en **Run workflow**
6. Espera ~2-3 minutos.
7. El bot hará commit automático de los resultados en `knowledge/` y `journal/`.

### Workflow 2: Fetch de Datos (Automático Diario)

Este workflow corre **automáticamente de lunes a viernes a las 9:00 UTC**. También puedes dispararlo manualmente.

### Workflow 3: Scout Semanal (Ejemplo Programado)

Corre **todos los domingos a las 18:00 UTC**. Placeholder para el Scout Engine futuro.

### Ver resultados de Actions

1. Ve a **Actions** en tu repo.
2. Clic en la ejecución reciente.
3. En la sección **"Commit results"** verás el hash del commit.
4. Ve al repo → el commit tendrá los archivos nuevos en `knowledge/` y `journal/`.

---

## 📝 Flujo de trabajo recomendado

### Para tu primera empresa (MELI ya incluida)

**Paso 1 — Conocimiento humano (obligatorio)**

Abre estos archivos en el editor de Codespaces y escribe tu análisis:

1. `knowledge/companies/MELI/static/wiki.md` — Modelo de negocio, moat, catalizadores.
2. `knowledge/companies/MELI/static/risks.md` — Riesgos estructurales.
3. `journal/companies/MELI/OPP-2026-001/hypotheses.yml` — Hipótesis + predicciones + **condiciones de falsación**.

> **Sin condiciones de falsación no existe tesis válida para el IDOS.** (Documento 6, §8)

**Paso 2 — Ejecuta el pipeline**

```bash
python main.py --pipeline MELI --provider gemini
```

**Paso 3 — Revisa resultados**

En Codespaces, abre:
- `journal/companies/MELI/OPP-2026-001/assessments/` → lo que dijo el LLM
- `journal/companies/MELI/OPP-2026-001/decisions/` → la decisión del sistema
- `knowledge/companies/MELI/dynamic/financials.json` → datos descargados

**Paso 4 — Itera y compara proveedores**

```bash
# Comparar assessments de diferentes proveedores
python main.py --pipeline MELI --provider openai
python main.py --pipeline MELI --provider gemini
python main.py --pipeline MELI --provider mistral

# Luego revisa los 3 assessments generados y compara calidad
```

### Para añadir una nueva empresa

```bash
# 1. Crea estructura
mkdir -p knowledge/companies/ASML/static
mkdir -p knowledge/companies/ASML/dynamic
mkdir -p journal/companies/ASML/OPP-2026-002/assessments
mkdir -p journal/companies/ASML/OPP-2026-002/decisions

# 2. Copia plantillas
cp knowledge/companies/MELI/static/wiki.md knowledge/companies/ASML/static/wiki.md
cp knowledge/companies/MELI/static/risks.md knowledge/companies/ASML/static/risks.md
cp journal/companies/MELI/OPP-2026-001/opportunity.yml journal/companies/ASML/OPP-2026-002/
cp journal/companies/MELI/OPP-2026-001/hypotheses.yml journal/companies/ASML/OPP-2026-002/

# 3. Edita los archivos para ASML
# 4. Ejecuta
python main.py --pipeline ASML --opp-id OPP-2026-002 --provider openrouter
```

---

## 🔐 Seguridad

| Elemento | Dónde va | Por qué |
|----------|----------|---------|
| API Keys (OpenAI, Gemini, Mistral, OpenRouter) | GitHub Secrets | Nunca en archivos del repo. Inyectadas en runtime. |
| Decisiones de inversión | Repo privado | Tu journal es información sensible. |
| Datos de mercado | `knowledge/` (repo) | Públicos, pero versionados para trazabilidad. |
| Prompts del LLM | `sdk/ai.py` (repo) | Parte del sistema, versionados con el código. |

---

## 🧩 Principios arquitectónicos preservados (SDD)

| Principio SDD | Implementación MVP GitHub |
|---------------|---------------------------|
| **Separación knowledge/journal** | Carpetas `knowledge/` y `journal/` |
| **Git como fuente de verdad** | Todo es YAML/Markdown; commits automáticos |
| **Interfaz abstracta de mercado** | `sdk.market.MarketDataProvider` → `YFinanceProvider` |
| **Interfaz abstracta de LLM** | `sdk.ai.LLMProvider` → 4 implementaciones |
| **Multi-provider (Doc 16)** | 4 proveedores, selección manual/auto |
| **Reglas externas en YAML** | `rules/entry.yml` |
| **Modelo de dominio Pydantic** | `sdk.models` fiel a Documento 4 (IKM) |
| **Obsidian-compatible** | Markdown plano con frontmatter YAML |
| **Human-in-the-Loop** | Tú escribes wiki, hipótesis, y apruebas decisiones |

---

## 📋 Checklist de validación

- [ ] Repo creado en GitHub (privado)
- [ ] Al menos un secret configurado: `OPENAI_API_KEY`, `GEMINI_API_KEY`, `MISTRAL_API_KEY`, o `OPENROUTER_API_KEY`
- [ ] Codespace abierto y dependencias instaladas
- [ ] `python scripts/setup_repo.py` muestra al menos 1 proveedor ✅
- [ ] `python main.py --pipeline MELI` ejecuta sin errores
- [ ] Se genera un archivo en `journal/companies/MELI/OPP-2026-001/assessments/`
- [ ] Se genera un archivo en `journal/companies/MELI/OPP-2026-001/decisions/`
- [ ] El assessment tiene score entre 0-100
- [ ] La decisión refleja el estado (APPROVED / WATCHLIST)
- [ ] Puedes ejecutar con `--provider gemini` (u otro) y obtener resultado diferente
- [ ] Puedes ejecutar el workflow de Actions manualmente

---

## 🆘 Troubleshooting

### "No module named 'mistralai'"
```bash
pip install -r requirements.txt
```

### "Se requiere MISTRAL_API_KEY" (u otro proveedor)
- Verifica que el secret esté configurado en **Settings → Secrets → Actions**.
- En Codespaces: `export MISTRAL_API_KEY=...` en la terminal.
- O usa otro proveedor: `python main.py --pipeline MELI --provider gemini`

### "yfinance failed to download data"
- Algunos tickers no están disponibles en yfinance.
- Prueba con `AAPL`, `MSFT`, `GOOGL` como verificación.
- Verifica conexión a internet en Codespaces.

### "Error parseando YAML del LLM"
- El LLM a veces devuelve markdown fences (```yaml).
- El código ya limpia esto automáticamente, pero si persiste:
  - Baja `temperature` en `sdk/ai.py`.
  - Aumenta el system prompt con "Responde SOLO en YAML, sin markdown fences."
  - Prueba otro proveedor: `--provider openai` suele ser más obediente con formato.

### "git push failed" en Actions
- Verifica que el workflow tenga permiso `contents: write`.
- Verifica que la rama se llame `main` (no `master`).

### Comparación de proveedores
Si quieres calibrar qué proveedor da mejores assessments:
```bash
for p in openai gemini mistral openrouter; do
  python main.py --pipeline MELI --provider $p
done
# Luego compara los 4 archivos en assessments/
```

---

## 📖 Referencias SDD

- Documento 1: Visión del Sistema
- Documento 4: Investment Knowledge Model (IKM)
- Documento 5: Investment Decision Framework (IDF)
- Documento 6: Hypothesis Management Framework
- Documento 11: System Architecture Overview
- Documento 13: Investment Knowledge Model (Técnico)
- Documento 15: SDK Contracts & Development Framework
- Documento 16: Reliability & Resilience Architecture (Multi-Provider)

---

*Generado por IDOS Architecture Assistant. 2026-07-15.*
*Multi-Provider: OpenAI, Gemini, Mistral AI, OpenRouter.*
